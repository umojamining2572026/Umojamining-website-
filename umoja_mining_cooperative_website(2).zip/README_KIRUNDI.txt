UMOJA MINING COOPERATIVE — AMABWIRIZA YO GUSHIRA WEBSITE KURI INTERNET

Iyi dosiye irimwo website yateguwe hisunzwe amakuru twaganiriye:
- Izina: Umoja Mining Cooperative
- Ibiro: Rumonge, Burundi; ibikorwa mu Burundi bwose
- WhatsApp: +257 71 55 34 60 na +257 79 13 57 05
- ROG yashizwe hejuru nk'ikirango c'inyandiko. Nimba ufise ifoto nyayo ya logo ROG, izosubirira ayo majambo.
- Amateka n'amazina yashizwemwo nk'uko watanze amakuru.

UKO BIKORESHWA
1. Banza ufungure iyi ZIP (Extract) kuri telefone canke kuri mudasobwa.
2. Dosiye nyamukuru ni index.html; style.css na script.js ni izindi dosiye zifasha website.
3. Ushobora gushira izi dosiye kuri GitHub repository yawe, hanyuma ugafungura Settings > Pages, ugahitamo branch main na folder /(root), ukabika.
4. Nimba uri kuri app iterekana GitHub Pages, fungura github.com ukoresheje browser ya telefone.
5. Amafoto y'abatanguje ishirahamwe na ROG nyayo ntarimwo muri iyi dosiye kuko ayo mafoto atari muri ubu butumwa. Ushobora kuyongerako nyuma.

ICITONDERWA
Ivyerekeye ubwoko bw'ubutare vyanditswe nk'amakuru rusangi; imbere yo kuvuga ko ubwoko kanaka buri mu bubiko canke bugurishwa, banza wemeze ubwinshi n'uko bumeze.

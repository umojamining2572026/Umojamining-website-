UMOJA MINING COOPERATIVE — DOSIYE ZA WEBSITE MU KIRUNDI

1. index.html: ni dosiye nyamukuru ya website. Ushobora kuyihindura izina ukayita index.html imbere yo kuyishira kuri GitHub.
2. rog.svg: ikirangantego ca koperative. Shira dosiye y'ikirangantego muri folder imwe na index.html. Nimba utagifise, website izokora ariko ikirangantego ntikizoboneka.
3. Nimba ukoresha GitHub Pages, shira index.html na rog.svg muri repository imwe, hanyuma commit/push.

Website irimwo nimero za WhatsApp zari zisanzwe muri dosiye watanze. Raba ko ari zo ushaka gukoresha imbere yo kuyitangaza.
